#ifndef AIRGEAD_BANKING_USERINPUT_H_
#define AIRGEAD_BANKING_USERINPUT_H_

class UserInput {
public:
    // Method to get the initial investment amount from the user
    double getInitialInvestment() const;

    // Method to get the monthly deposit amount from the user
    double getMonthlyDeposit() const;

    // Method to get the annual interest rate from the user
    double getAnnualInterest() const;

    // Method to get the number of years from the user
    int getNumYears() const;
};

#endif // AIRGEAD_BANKING_USERINPUT_H_
