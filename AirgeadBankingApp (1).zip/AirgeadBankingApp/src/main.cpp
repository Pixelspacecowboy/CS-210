#include "Investment.h"
#include "UserInput.h"
#include "Display.h"

int main() {
    UserInput userInput;

    double initial_investment = userInput.getInitialInvestment();
    double monthly_deposit = userInput.getMonthlyDeposit();
    double annual_interest = userInput.getAnnualInterest();
    int num_years = userInput.getNumYears();

    Investment investment(initial_investment, monthly_deposit, annual_interest, num_years);

    std::vector<double> no_deposit = investment.calculateYearlyBalanceNoDeposit();
    std::vector<double> with_deposit = investment.calculateYearlyBalanceWithDeposit();

    Display display;
    display.displayResults(no_deposit, with_deposit);

    return 0;
}
