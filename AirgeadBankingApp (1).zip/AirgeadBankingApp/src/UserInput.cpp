#include "UserInput.h"
#include <iostream>
#include <limits>

double UserInput::getInitialInvestment() const {
    double initial_investment;
    while (true) {
        std::cout << "Enter initial investment amount: $";
        std::cin >> initial_investment;
        if (std::cin.fail() || initial_investment < 0) {
            std::cin.clear(); // clear the error flag
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // discard invalid input
            std::cout << "Invalid input. Please enter a positive number.\n";
        } else {
            break;
        }
    }
    return initial_investment;
}

double UserInput::getMonthlyDeposit() const {
    double monthly_deposit;
    while (true) {
        std::cout << "Enter monthly deposit amount: $";
        std::cin >> monthly_deposit;
        if (std::cin.fail() || monthly_deposit < 0) {
            std::cin.clear(); // clear the error flag
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // discard invalid input
            std::cout << "Invalid input. Please enter a positive number.\n";
        } else {
            break;
        }
    }
    return monthly_deposit;
}

double UserInput::getAnnualInterest() const {
    double annual_interest;
    while (true) {
        std::cout << "Enter annual interest rate (in %): ";
        std::cin >> annual_interest;
        if (std::cin.fail() || annual_interest < 0) {
            std::cin.clear(); // clear the error flag
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // discard invalid input
            std::cout << "Invalid input. Please enter a positive number.\n";
        } else {
            break;
        }
    }
    return annual_interest;
}

int UserInput::getNumYears() const {
    int num_years;
    while (true) {
        std::cout << "Enter number of years: ";
        std::cin >> num_years;
        if (std::cin.fail() || num_years < 1) {
            std::cin.clear(); // clear the error flag
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // discard invalid input
            std::cout << "Invalid input. Please enter a positive integer.\n";
        } else {
            break;
        }
    }
    return num_years;
}
