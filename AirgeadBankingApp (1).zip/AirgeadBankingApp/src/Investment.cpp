#include "Investment.h"
#include <cmath>

// Constructor implementation
Investment::Investment(double initial_investment, double monthly_deposit, double annual_interest, int num_years)
    : m_initial_investment(initial_investment),
      m_monthly_deposit(monthly_deposit),
      m_annual_interest(annual_interest),
      m_num_years(num_years) {}

// Calculate yearly balance without monthly deposits
std::vector<double> Investment::calculateYearlyBalanceNoDeposit() const {
    std::vector<double> yearly_balances;
    double balance = m_initial_investment;
    for (int year = 1; year <= m_num_years; ++year) {
        double interest = balance * (m_annual_interest / 100);
        balance += interest;
        yearly_balances.push_back(balance);
    }
    return yearly_balances;
}

// Calculate yearly balance with monthly deposits
std::vector<double> Investment::calculateYearlyBalanceWithDeposit() const {
    std::vector<double> yearly_balances;
    double balance = m_initial_investment;
    for (int year = 1; year <= m_num_years; ++year) {
        for (int month = 1; month <= 12; ++month) {
            balance += m_monthly_deposit;
            double interest = balance * (m_annual_interest / 100 / 12);
            balance += interest;
        }
        yearly_balances.push_back(balance);
    }
    return yearly_balances;
}
