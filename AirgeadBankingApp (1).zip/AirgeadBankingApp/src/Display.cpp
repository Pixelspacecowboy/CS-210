#include "Display.h"
#include <iostream>
#include <iomanip>

void Display::displayResults(const std::vector<double>& no_deposit, const std::vector<double>& with_deposit) const {
    std::cout << std::fixed << std::setprecision(2);

    std::cout << "Yearly Balances without Monthly Deposits:\n";
    for (size_t year = 0; year < no_deposit.size(); ++year) {
        std::cout << "Year " << year + 1 << ": $" << no_deposit[year] << "\n";
    }

    std::cout << "\nYearly Balances with Monthly Deposits:\n";
    for (size_t year = 0; year < with_deposit.size(); ++year) {
        std::cout << "Year " << year + 1 << ": $" << with_deposit[year] << "\n";
    }
}
