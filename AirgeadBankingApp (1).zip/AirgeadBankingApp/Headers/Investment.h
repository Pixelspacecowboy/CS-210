#ifndef AIRGEAD_BANKING_INVESTMENT_H_
#define AIRGEAD_BANKING_INVESTMENT_H_

#include <vector>

class Investment {
private:
    double m_initial_investment;
    double m_monthly_deposit;
    double m_annual_interest;
    int m_num_years;

public:
    // Constructor
    Investment(double initial_investment, double monthly_deposit, double annual_interest, int num_years);

    // Method to calculate yearly balance without monthly deposits
    std::vector<double> calculateYearlyBalanceNoDeposit() const;

    // Method to calculate yearly balance with monthly deposits
    std::vector<double> calculateYearlyBalanceWithDeposit() const;
};

#endif // AIRGEAD_BANKING_INVESTMENT_H_
