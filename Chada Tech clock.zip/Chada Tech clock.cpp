// Joshua Emmons
// CS-210


#include <iostream>
#include <iomanip>
#include <limits>

// Clock class to manage time and display functions
class Clock {
private:
    int hours;
    int minutes;
    int seconds;

public:
    // Constructor to initialize clock time
    Clock(int h = 0, int m = 0, int s = 0) : hours(h), minutes(m), seconds(s) {}

    // Function to add an hour
    void addHour() {
        hours = (hours + 1) % 24;
    }

    // Function to add a minute
    void addMinute() {
        minutes = (minutes + 1) % 60;
        if (minutes == 0) addHour(); // Increment hour if minutes roll over
    }

    // Function to add a second
    void addSecond() {
        seconds = (seconds + 1) % 60;
        if (seconds == 0) addMinute(); // Increment minute if seconds roll over
    }

    // Function to display the 12-hour clock
    void display12Hour() const {
        int display_hour = hours % 12;
        if (display_hour == 0) display_hour = 12;
        std::string am_pm = (hours < 12) ? "AM" : "PM";
        std::cout << "12-Hour Clock: " << std::setw(2) << std::setfill('0') << display_hour << ":"
                  << std::setw(2) << std::setfill('0') << minutes << ":"
                  << std::setw(2) << std::setfill('0') << seconds << " " << am_pm << std::endl;
    }

    // Function to display the 24-hour clock
    void display24Hour() const {
        std::cout << "24-Hour Clock: " << std::setw(2) << std::setfill('0') << hours << ":"
                  << std::setw(2) << std::setfill('0') << minutes << ":"
                  << std::setw(2) << std::setfill('0') << seconds << std::endl;
    }
};

// Function to display the menu
void displayMenu() {
    std::cout << "\nMenu:\n";
    std::cout << "1. Add One Hour\n";
    std::cout << "2. Add One Minute\n";
    std::cout << "3. Add One Second\n";
    std::cout << "4. Exit\n";
    std::cout << "Enter your choice: ";
}

// Main function to drive the program
int main() {
    Clock clock;
    int choice;

    while (true) {
        // Display both clocks
        clock.display12Hour();
        clock.display24Hour();

        // Display menu and get user choice
        displayMenu();
        if (!(std::cin >> choice)) {
            std::cin.clear(); // Clear the error flag
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Ignore the rest of the input
            std::cout << "Invalid input. Please enter a number between 1 and 4." << std::endl;
            continue;
        }

        // Respond to user input
        switch (choice) {
            case 1:
                clock.addHour();
                break;
            case 2:
                clock.addMinute();
                break;
            case 3:
                clock.addSecond();
                break;
            case 4:
                std::cout << "Exiting program." << std::endl;
                return 0;
            default:
                std::cout << "Invalid choice. Please try again." << std::endl;
        }
    }
}
