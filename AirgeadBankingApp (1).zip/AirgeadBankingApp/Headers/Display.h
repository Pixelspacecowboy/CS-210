#ifndef AIRGEAD_BANKING_DISPLAY_H_
#define AIRGEAD_BANKING_DISPLAY_H_

#include <vector>

class Display {
public:
    // Method to display the results
    void displayResults(const std::vector<double>& no_deposit, const std::vector<double>& with_deposit) const;
};

#endif // AIRGEAD_BANKING_DISPLAY_H_
