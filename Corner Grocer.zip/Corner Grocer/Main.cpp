/*
 * Main.cpp
 *
 *  Created on: Jun 10, 2024
 *      Author: joshuaemmons_snhu
 */
#include <iostream>
#include <fstream>
#include <unordered_map>
#include <string>
#include <iomanip>

// GroceryTracker class definition
class GroceryTracker {
private:
    // Private member to store item frequencies
    std::unordered_map<std::string, int> itemFrequency;

    // Private method to read input file and populate itemFrequency map
    void readInputFile(const std::string& filename);

    // Private method to write frequency data to a backup file
    void writeFrequencyData(const std::string& filename);

public:
    // Constructor to initialize the program by reading input and writing backup
    GroceryTracker(const std::string& inputFilename, const std::string& outputFilename);

    // Method to display the menu and handle user input
    void displayMenu();

    // Method to search for an item and display its frequency
    void searchItem();

    // Method to print the list of items with their frequencies
    void printFrequencyList();

    // Method to print a histogram of item frequencies
    void printHistogram();
};

// Method to read the input file and populate the itemFrequency map
void GroceryTracker::readInputFile(const std::string& filename) {
    std::ifstream inputFile(filename);
    std::string item;

    // Read each item from the file and increment its frequency in the map
    while (inputFile >> item) {
        itemFrequency[item]++;
    }
    inputFile.close();
}

// Method to write the frequency data to a backup file
void GroceryTracker::writeFrequencyData(const std::string& filename) {
    std::ofstream outputFile(filename);

    // Write each item and its frequency to the output file
    for (const auto& pair : itemFrequency) {
        outputFile << pair.first << " " << pair.second << std::endl;
    }
    outputFile.close();
}

// Constructor to initialize the GroceryTracker object
GroceryTracker::GroceryTracker(const std::string& inputFilename, const std::string& outputFilename) {
    readInputFile(inputFilename);  // Read input file
    writeFrequencyData(outputFilename);  // Write initial frequency data to backup file
}

// Method to display the menu and handle user input
void GroceryTracker::displayMenu() {
    int choice;
    do {
        // Display menu options
        std::cout << "1. Search for an item\n";
        std::cout << "2. Print frequency list\n";
        std::cout << "3. Print histogram\n";
        std::cout << "4. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        // Handle user input and call corresponding methods
        switch (choice) {
            case 1:
                searchItem();
                break;
            case 2:
                printFrequencyList();
                break;
            case 3:
                printHistogram();
                break;
            case 4:
                std::cout << "Exiting the program.\n";
                break;
            default:
                std::cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 4);
}

// Method to search for an item and display its frequency
void GroceryTracker::searchItem() {
    std::string item;
    std::cout << "Enter item to search: ";
    std::cin >> item;
    std::cout << item << " was purchased " << itemFrequency[item] << " times.\n";
}

// Method to print the list of items with their frequencies
void GroceryTracker::printFrequencyList() {
    // Iterate through the map and print each item and its frequency
    for (const auto& pair : itemFrequency) {
        std::cout << pair.first << " " << pair.second << std::endl;
    }
}

// Method to print a histogram of item frequencies
void GroceryTracker::printHistogram() {
    // Iterate through the map and print each item with asterisks representing its frequency
    for (const auto& pair : itemFrequency) {
        std::cout << pair.first << " ";
        for (int i = 0; i < pair.second; ++i) {
            std::cout << "*";
        }
        std::cout << std::endl;
    }
}

// Main function to create a GroceryTracker object and start the menu
int main() {
    GroceryTracker tracker("CS210_Project_Three_Input_File.txt", "frequency.dat");
    tracker.displayMenu();
    return 0;
}




